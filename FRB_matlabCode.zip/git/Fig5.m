%This program is designed to generate the composite figure 5. It requires 
%data files such as Fig5a.mat, Fig5b.mat, Fig5c.mat, and Fig5d.mat. 
%Prior to running this program, the files Fig5ab.m and Fig5cd.m must
%be executed in the current directory to generate the aforementioned data files.
clear all;
figure;

tiledlayout(2, 2); 
load('Fig5a.mat')
nexttile(1);
   imagesc(T, F, abs(S).^2); axis xy; 
    xlabel('Time'); ylabel('Frequency');
 text(0.9,15,'(a)','fontsize',15,'color','white')
 
load('Fig5b.mat')
    nexttile(2);
    imagesc(T, F, abs(S).^2); axis xy;
    xlabel('Time'); ylabel('Frequency'); 
     text(0.9,15,'(b)','fontsize',15,'color','white')
    
load('Fig5c.mat')   
nexttile(3);
imagesc(f_t*1000,frec/1e9,spectrum1)
set(gca,'YDir','normal','xlim',xlim)
title(['DM=0'])
xlabel('t(ms)')
ylabel('Frequency (GHz)')
text(2,1.65,'(c)','fontsize',15,'color','white')
       
load('Fig5d.mat')
nexttile(4);
imagesc(f_t2*1000,frec/1e9,spectrum2)
set(gca,'YDir','normal')
title(['DM=-9.3'])
xlabel('t(ms)')
ylabel('Frequency (GHz)')
 text(0.5,1.65,'(d)','fontsize',15,'color','white')

   