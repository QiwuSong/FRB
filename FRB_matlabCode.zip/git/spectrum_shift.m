%Huangyu 2019-05-01
function [spectrum1,f_t]=spectrum_shift(spectrum,dm1)


global  dt frec f_num

dmt=abs(dm1);
t_num=size(spectrum,2);
f_t1=4148.808*(dmt)./(frec/1e6).^2;
f_t1=f_t1-f_t1(1);

t_numt=ceil(f_t1./dt)+1;
t_num1=t_num+max(t_numt);
spectrum1=zeros(f_num,t_num1);

if dm1>=0
    for i=1:f_num
    spectrum1(i,t_numt(i):t_num+t_numt(i)-1)=spectrum(i,:);
    end
    f_t=0:dt:abs(t_num*dt)+f_t1(end)+dt;
else
    for i=1:f_num
    spectrum1(i,t_num1-(t_num+t_numt(i)-1):t_num1-t_numt(i))=spectrum(i,:);
    end
    f_t=0:dt:abs(t_num*dt)+f_t1(end)+dt;
end
end