
%This program is designed to generate the composite figure 4. It requires 
%data files such as Fig4a.mat, Fig4b.mat, Fig4c.mat, and Fig4d.mat. 
%Prior to running this program, the files Fig4a,b,c,d.m  must
%be executed in the current directory to generate the aforementioned data files.
clear all;

figure;

tiledlayout(2, 4); 

%    :::::::::gb_01
load('Fig4a.mat')
nexttile;
 plot(T,sum(abs(S),1).^2/10000);
    title(['GB-01']);
   xlabel ('Time'); ylabel ('Intensity');
     set(gca,'xlim',[0,33])

nexttile(5);
   imagesc(T, F, abs(S).^2); axis xy;
    xlabel('Time'); ylabel('Frequency');
    set(gca,'xlim',[0,33])
    %:::::::::gb_02
    load('Fig4b.mat')
nexttile(2);
 plot(T,sum(abs(S),1).^2/10000);
    title(['GB-02']);
   xlabel ('Time'); ylabel ('Intensity');
    set(gca,'xlim',[0,25])
nexttile(6);
   imagesc(T, F, abs(S).^2); axis xy;
    xlabel('Time'); ylabel('Frequency');
      set(gca,'xlim',[0,25])
    %:::::::::gb_03
load('Fig4c.mat')
nexttile(3);
  plot(T,sum(abs(S),1).^2/10000);
    title(['GB-03']);
   xlabel ('Time'); ylabel ('Intensity');
     set(gca,'xlim',[0,25])
nexttile(7);
    imagesc(T, F, abs(S).^2); axis xy;
    xlabel('Time'); ylabel('Frequency');
      set(gca,'xlim',[0,25])
    
    load('Fig4d.mat')
    nexttile(4);
 plot(T,sum(abs(S),1).^2/100000);
    title(['AO-11']);
   xlabel ('Time'); ylabel ('Intensity');
     set(gca,'xlim',[8,15])
nexttile(8);

    imagesc(T, F, abs(S).^2); axis xy;
    xlabel('Time'); ylabel('Frequency');
      set(gca,'xlim',[8,15])



   