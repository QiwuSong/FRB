%By Songqw
% Clear workspace and setup initial parameters
clear all;
clc;

N=7;
beta2 = -1;
beta3 = 0.06;
raman = 0.06;
s = 0.05  ;
z = 0.82;


T = 100;
nt = 2^12;
dt = T / nt;
t = ((1:nt)' - (nt+1) / 2) * dt;
w = wspace(T, nt);  % Ensure 'wspace' function is defined or available in your MATLAB path
vs = fftshift(w / (2*pi));

 fig = figure(1);
    
                
 betap = [0, 0, beta2, beta3];
    nz = 5000;
    dz = z / nz;
    u0 = solitonpulse(t);  % Ensure 'solitonpulse' function is defined
    u = sspropc(u0, dt, dz, nz, 0, betap, N^2, raman, 2 * pi * s);  % Ensure 'sspropc' function is defined
    U = fftshift(fft(u));
 [S, F, T] = spectrogram(u(1600:3000), hann(16), 14, [], 1/dt, 'centered');

    subplot(211);  plot(T,sum(abs(S),1).^2/10000);
    title(['GB-01']);
   xlabel ('Time'); ylabel ('Intensity');
    set(gca,'xlim',[0,34])
    subplot(212);
    imagesc(T, F, abs(S).^2); axis xy;
    xlabel('Time'); ylabel('Frequency');
save('Fig4a.mat', 'S', 'T', 'F');




