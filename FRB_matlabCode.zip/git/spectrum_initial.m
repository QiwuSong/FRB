%Huangyu 2019-05-01
function [spectrum,f_t,fret]=spectrum_initial(fh,fl,dm,sigma,f1,p1,mu)
global omegahigh omegalow
global deltaOmega dt f_num frec



tini=4148.808*(abs(dm)./(fh/1e6).^2);
tend=4148.808*(abs(dm)./(fl/1e6).^2);

f_t=0:dt:abs(tini-tend)+dt;
f_t1=f_t+tini;
t_num=abs(ceil((tini-tend)/dt))+1;


if dm>=0
    fret=sqrt(4148.808*(dm)./f_t1)*1e6;
else
    f_t1=f_t-tend;
    fret=sqrt(4148.808*(dm)./f_t1)*1e6;
end


si=sigma*t_num;
xn=-t_num:1:t_num;
yn=normpdf(xn,mu,si);
yn=yn./max(yn);
    
figure(1)
plot(xn,yn)
ini=ceil(t_num*0.3);
%generation of the spectrum with the given DM

spectrum=zeros(f_num,t_num);
num=length(f1);
for i=1:t_num
    ftemp=f1*fret(i);
    num_f1=ceil((ftemp(end)-ftemp(1))/deltaOmega);
    xf=ftemp(1):deltaOmega:ftemp(end);
    yspe=interp1(ftemp,p1,xf);
    
    indexh=find(xf<=omegahigh,1,'last');
    indexl=find(xf>=omegalow,1,'first');
    
    yspe1=yspe(indexl:indexh);
    yspe1=flip(yspe1);
    %xf(indexh)
    ss=find(frec>=xf(indexh),1,'last')-1;
    spectrum(1+ss:length(yspe1)+ss,i)=yspe1*yn(i+ini);
    
end
hold on
plot([xn(1+ini),xn(1+ini)],[0,1])
plot([xn(t_num+ini),xn(t_num+ini)],[0,1])
hold off
end