%Huangyu 2019-05-01
function [spectrum,f_t,fret]=spectrum_initial(fret,t_dur,sigma,f1,p1,mu)

global omegahigh omegalow
global deltaOmega dt f_num frec

t_num=ceil(t_dur/dt);


si=sigma*t_num;
xn=-t_num:1:t_num;
yn=normpdf(xn,mu,si);
yn=yn./max(yn);
    
figure(1)
plot(xn,yn)
ini=ceil(t_num*0.3);
%generation of the spectrum with the given DM

spectrum=zeros(f_num,t_num);
num=length(f1);
for i=1:t_num
    ftemp=f1*fret;
    num_f1=ceil((ftemp(end)-ftemp(1))/deltaOmega);
    xf=ftemp(1):deltaOmega:ftemp(end);
    yspe=interp1(ftemp,p1,xf);
    
    indexh=find(xf<=omegahigh,1,'last');
    indexl=find(xf>=omegalow,1,'first');
    
    yspe1=yspe(indexl:indexh);
    yspe1=flip(yspe1);
    %xf(indexh)
    ss=find(frec>=xf(indexh),1,'last')-1;
    spectrum(1+ss:length(yspe1)+ss,i)=yspe1*yn(i+ini);
    
end
hold on
plot([xn(1+ini),xn(1+ini)],[0,1])
plot([xn(t_num+ini),xn(t_num+ini)],[0,1])
hold off
end