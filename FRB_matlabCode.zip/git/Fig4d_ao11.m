% Clear workspace and setup initial parameters
clear all;
clc;
%parameterSet set the folder of the output mp4 file and the N number 
rootFolder='d:\output\'
N=6
z=4.08

%%%%%%%%%%%%%%


T = 100;
nt = 2^12;
dt = T / nt;
t = ((1:nt)' - (nt+1) / 2) * dt;
w = wspace(T, nt);  % Ensure 'wspace' function is defined or available in your MATLAB path
vs = fftshift(w / (2*pi));
beta2 = -1;



 fig = figure(1);

    
 
                
%                         runSimulation(N, beta2, beta3, raman, s, z, t, dt, vs, videoWriter, fig);
 betap = [0, 0, beta2,0];
    nz = 5000;
    dz = z / nz;
    u0 = solitonpulse(t);  % Ensure 'solitonpulse' function is defined
    u = sspropc(u0, dt, dz, nz, 0, betap, N^2);  % Ensure 'sspropc' function is defined
    U = fftshift(fft(u));
 [S, F, T] = spectrogram(u(1600:3000), hann(16), 14, [], 1/dt, 'centered');
    % Update figure for new simulation parameters



    subplot(211);  plot(T,sum(abs(S),1).^2/10000);
    title(['AO-11']);
   xlabel ('Time'); ylabel ('Intensity');

    subplot(212);
    imagesc(T, F, abs(S).^2); axis xy;
    xlabel('Time'); ylabel('Frequency');

    % Capture and write frame
             
               
 save('Fig4d.mat', 'S', 'T', 'F');


