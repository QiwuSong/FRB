function [P,f]=fft_f_p(wave,sampling_frequency)
% return P, the fourier transform of the wave, and the corresponding  normalized frequency f 
%By Huangyu
Fs = sampling_frequency;            % Sampling frequency, also the number of points in one normal wave period
T = 1/Fs;                           % Sampling period
L = length(wave);
L=L-mod(L,2);                       % keep L an even number
% Length of signal
t = (0:L-1)*T;  
fre=fft(wave);
P2 = abs(fre/L);
P = P2(1:L/2+1);
P(2:end-1) = 2*P(2:end-1);
f = Fs*(0:(L/2))/L;
end
