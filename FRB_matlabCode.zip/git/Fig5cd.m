% Hessels, J. W. T., et al. 2019, The Astrophysical Journal Letters, 876
%the burst AO-06
%by Huang Yu huangyu@pmo.ac.cn and Song Qiwu songqw@pmo.ac.cn
clear global
clear 
%Simulation of the spectrum with a DM
global omegahigh omegalow
global deltaOmega dt frec f_num

omegahigh=1.73e9;             % The high-frequency limit of observation
omegalow=1.15e9;              % The low-frequency limit of observation

dm=-3.1;
dm1=3.3;
dm2=-6.2

bg=0.07;                % background noise level

% a gaussian evolpe of energy distribution of radiation particles
sigma=0.16;  mu=-100             
           
fh=1.99e9;              % The high frequency of DM line
fl=1.19e9;              % The low  frequency of DM line
% Number of undulator periods N and Taper parameter eTa,
%spatial frequency increasing eTa over N periods
w=5.439584;eTa=0.465;
N=2*w/log(1+eTa) %N is determined by w, so that it can be continuous.    
                                 
 %a gaussian envelope of magnetic field 
  MuWave=0.50/2;  SigmaWave=1.198;  

  %blending parameter of figure(7)
 alpha=0.65
xlim=[1.6,8.6]

%trival parameter for discretezation
deltaOmega=1e5;         % The resolution of frequency,in unit of Hz
dt=1e-5;                 % time resolution
%;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

[P,f]=InstanSpecGaussianFout(N,eTa,SigmaWave,MuWave);
P=P.*P;

f=f-eTa/2; 
inif1=find(f>=0.6,1,'first');
inif2=find(f>=1.4,1,'first');
f1=f(inif1:inif2);
pPlot=P(inif1:inif2);
p1=(pPlot-bg)/bg;  
index=find(p1<=0);
p1(index)=0;



figure(2)
plot(f1,p1)


frec=omegahigh:-1*deltaOmega:omegalow;
f_num=(omegahigh-omegalow)/deltaOmega+1;
[spectrum,f_t0,fret]=spectrum_initial(fh,fl,dm,sigma,f1,p1,mu);

for i=1:f_num;
    spectrum(i,:)=(frec(i)/frec(1))^2*spectrum(i,:);
  
end


figure(4)
 [spectrum2,f_t2]=spectrum_shift(spectrum,dm2);
imagesc(f_t2*1000,frec/1e9,spectrum2)
set(gca,'YDir','normal')
title(['DM=-9.3'])
xlabel('t(ms)')
ylabel('Frequency (GHz)')
 save('Fig5d.mat', 'f_t2', 'frec', 'spectrum2');
 
 figure(5)
[spectrum1,f_t]=spectrum_shift(spectrum,dm1);
imagesc(f_t*1000,frec/1e9,spectrum1)
set(gca,'YDir','normal','xlim',xlim)
title(['DM=0'])
xlabel('t(ms)')
ylabel('Frequency (GHz)')
 save('Fig5c.mat', 'f_t', 'frec', 'spectrum1','xlim');
 

