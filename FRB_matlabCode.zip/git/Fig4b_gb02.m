% Clear workspace and setup initial parameters
clear all;
N=10
zEnd=0.3
T = 100;
nt = 2^12;
dt = T / nt;
t = ((1:nt)' - (nt+1) / 2) * dt;
w = wspace(T, nt);  % Ensure 'wspace' function is defined or available in your MATLAB path
vs = fftshift(w / (2*pi));
beta2 = -1;

 fig = figure(1);
 set(fig,'position',[50,50,450,600])   
    beta3 = 0.03
        raman = 0.05
        s = 0.02  
             z = 0.3
                
 betap = [0, 0, beta2, beta3];
    nz = 5000;
    dz = z / nz;
    u0 = solitonpulse(t);  % Set the initial value of the pulse as a fundamental soliton.
    u = sspropc(u0, dt, dz, nz, 0, betap, N^2, raman, 2 * pi * s);  % Ensure that the 'sspropc.mexw64' file is located in the current directory or within the search path.
    U = fftshift(fft(u));
 [S, F, T] = spectrogram(u(1600:3000), hann(16), 14, [], 1/dt, 'centered');
    parameterStr=strcat('N=',num2str(N),' beta3=',num2str(beta3),' raman=',...
   num2str(raman),' s=',num2str(s));

    subplot(211);  plot(T,sum(abs(S),1).^2/10000);
    title(['GB-02']);
   xlabel ('Time'); ylabel ('Intensity');
    subplot(212);
    imagesc(T, F, abs(S).^2); axis xy;
    xlabel('Time'); ylabel('Frequency');      
            
 save('Fig4b.mat', 'S', 'T', 'F');


