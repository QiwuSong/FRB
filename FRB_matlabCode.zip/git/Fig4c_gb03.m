% Clear workspace and setup initial parameters
%By Songqw
clear all;
clc;
N=19
zEnd=0.6
T = 100;
nt = 2^12;
dt = T / nt;
t = ((1:nt)' - (nt+1) / 2) * dt;
w = wspace(T, nt);  % Ensure 'wspace' function is defined or available in your MATLAB path
vs = fftshift(w / (2*pi));
beta2 = -1; 
    beta3 = 0.1
        raman = 0.07
            s = 0.01  
                z = 0.067

 betap = [0, 0, beta2, beta3];
    nz = 5000;
    dz = z / nz;
    u0 = solitonpulse(t);  % Ensure 'solitonpulse' function is defined
    u = sspropc(u0, dt, dz, nz, 0, betap, N^2, raman, 2 * pi * s);  % Ensure 'sspropc' function is defined
    U = fftshift(fft(u));
 [S, F, T] = spectrogram(u(1600:3000), hann(16), 14, [], 1/dt, 'centered');

 fig = figure(1);  
    subplot(211);  plot(T,sum(abs(S),1).^2/10000);
    title(['GB-03']);
   xlabel ('Time'); ylabel ('Intensity');
    subplot(212);
    imagesc(T, F, abs(S).^2); axis xy;
    xlabel('Time'); ylabel('Frequency');

   
save('Fig4c.mat', 'S', 'T', 'F');


