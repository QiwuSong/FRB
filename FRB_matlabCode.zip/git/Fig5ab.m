clear all;
T = 100;                                % time window (period)
nt = 2^12;                              % number of points
dt = T/nt;                              % timestep (dt)
t = ((1:nt)'-(nt+1)/2)*dt;              % time vector
w = wspace(T,nt);                       % angular frequency vector
vs = fftshift(w/(2*pi));                % shifted for plotting

figure(1)

 z=0.18
% z = 0.08;                          		% total distance
nz = 500;                               % total number of steps
dz = z/nz;                              % step-size

betap = [0,0,+1];						% dispersion polynomial

u0 = gaussian(t);

u = sspropc(u0,dt,dz,nz,0,betap,20^2);
U = fftshift(abs(dt*fft(u)/sqrt(2*pi)).^2);
subplot(221);

plot(t,abs(u0).^2);
 title('Original Pulse ');
 xlim([-5 5]);
xlabel ('(t-\beta_1z)/T_0');
ylabel ('|u(z,t)|^2/P_0');
subplot(222);
plot(t,abs(u).^2);
 title(['Pulse Evolution at z = ', num2str(z), ' units']);
 xlim([-5 5]);
xlabel ('(t-\beta_1z)/T_0');
ylabel ('|u(z,t)|^2/P_0');

subplot(223);
plot(vs,U);
xlim([-10 10]);
xlabel ('(\nu-\nu_0) T_0');
ylabel ('|U(z,\nu)|^2/P_0');
subplot(224);
 [S, F, T] =spectrogram(u(1600:2400),hann(48),46,[],1/dt,'MinThreshold',-18,'centered');
    imagesc(T, F, abs(S).^2); axis xy;
    xlabel('Time'); ylabel('Frequency');

figure(2)
[S, F, T] =spectrogram(u(1600:2400),hann(48),46,[],1/dt,'MinThreshold',-18,'centered');
    imagesc(T, F, abs(S).^2); axis xy; 
    xlabel('Time'); ylabel('Frequency');
     save('Fig5b.mat', 'S', 'T', 'F');
figure(3)
[S, F, T] =spectrogram(u0(1600:2400),hann(48),46,[],1/dt,'MinThreshold',-18,'centered');
    imagesc(T, F, abs(S).^2); axis xy;
    xlabel('Time'); ylabel('Frequency');
     save('Fig5a.mat', 'S', 'T', 'F');

