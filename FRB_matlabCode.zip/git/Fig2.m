
clear global
clear 
global omegahigh omegalow
global deltaOmega dt frec f_num
% Frequency settings
omegahigh = 10.5e9;       % Higher frequency of observation
omegalow = 8e9;           % Lower frequency of observation
fret = 9.2e9;             % Central frequency
deltaOmega = 1e5;         % Resolution of frequency in Hz


% DM of the inital curve is 0 and disperse it by dm
dm=0.05;

% Duration and pulse parameters
t_dur = 12e-6;            % Duration time of pulse
delta_t = 0.5e-6;        
sigma = 0.13;             % pulse width
mu = -60;                 % pulse's t position
alpha = 0.520;            % Alpha parameter for blend
dt = 1e-8;                % Time resolution
tx = -t_dur/2:dt:t_dur/2-dt; % Time vector

% Crab pulsar and GPs parameters
period = 0.033;           % Period of pulsar
high_freq = 10.2;         % Upper bound frequency of spectrum
low_freq = 8.2;           % Lower bound frequency of spectrum
Np = 4;                   % Number of peaks on spectrum
c = 3e5;                  % Light speed in km
cb=2          %for magnetar set it to 2, ordinary neutron
                %star set it to 1
r_end=1e7;
dr=100;


%blending parameter of figure(8)
alpha=0.520; 
xx=5.2;          %move the spectrum horizontally 
xlim=[xx,xx+6];  % x range of the plot, 6 microsecond 









% Derived parameters
omega=2*pi/period    % angular freqency
rL=c*period/(2*pi)   %radius of light cylinder
b=cb*0.046*1.5e8     % b is 0.046 Astronomical unit for the Sun, duoble it for magnetar 
FWHB=(high_freq-low_freq)/((high_freq+low_freq)/2) %eta from observation, i.e. relative bandwidth of the spectrum
eta=FWHB;
Nu=fix(4*Np/log(1+eta))
r0=sqrt(b*rL);



% Calculate pitches
eta = FWHB; 
Nu = fix(4*Np/log(1 + eta)); 
r0 = sqrt(b * rL);

% Define r and calculate corresponding phi
r = 0:dr:r_end; 
phi = r .* r / (b * rL);  

% Calculate positions on spiral
x1 = r .* cos(phi); 
y1 = r .* sin(phi); 
x2 = r .* cos(phi + pi); 
y2 = r .* sin(phi + pi); 

% Search for all r with phi = n * 2 * Pi
periodsNumber = fix(phi(end) / (2 * pi)); 

r_2pi = 0; 
for n = 2 * pi:2 * pi:phi(end)
    r_2pi(end + 1) = r(find(phi > n, 1))
end

% Calculate pitch lengths
lambda = diff(r_2pi);  
etaPitch = abs(1/lambda(1) - 1/lambda(Nu)) * lambda(1);

endEta = length(lambda) - Nu; 
for n = 2:endEta
    tmp = abs(1/lambda(n) - 1/lambda(n + Nu - 1)) * lambda(n);
    etaPitch = [etaPitch, tmp];
end 

% Plot the eta
figure(3)
plot(etaPitch, '*')
title('\eta')
%;;;;;;;;;;;;computing x,y from r and phi of the spiral;;;;;

%set the range of r and calculate corresponding phi
r=0:dr:r_end;
phi=r.*r/(b*rL);
%;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


x1 = r .* cos(phi);
y1 = r .* sin(phi);

%calculate the position of the current sheet on the oppsite side
%only used some in specific plot
x2 = r .* cos(phi+3.1416);
y2 = r .* sin(phi+3.1416);

% Search for all r with phi = n * 2 * Pi
periodsNumber = fix(phi(end) / (2 * pi)); 
r_2pi = zeros(1, periodsNumber); 

for n = 2 * pi:2 * pi:phi(end)
    r_2pi(end + 1) = r(find(phi > n, 1));
end

% Calculate pitch lengths
lambda = diff(r_2pi);  
etaPitch = abs(1/lambda(1) - 1/lambda(Nu)) * lambda(1);

endEta = length(lambda) - Nu; 
for n = 2:endEta
    tmp = abs(1/lambda(n) - 1/lambda(n + Nu - 1)) * lambda(n);
    etaPitch = [etaPitch, tmp];
end 

% Plot the eta
figure(3)
plot(etaPitch, '*')
title('\eta')

% % %;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
startPeriod=find(etaPitch<FWHB,1)
endPeriod=startPeriod+Nu-1


%;;;computing the total magnetic field at distance b::::::
b_r=1.6*10^(-3+cb-1)*47700^2./r_2pi.^2; 
b_phi=b_r;
%estimate B_phi from B field at Light-cylinder 
% at this scale b_r is proportional to to 1/R^2
%B field at Light-cylinder is 1.6*10^（-3） T
% from the table 7 of 50 J. Pétri.
%Pétri, J. (2016). "Theory of pulsar magnetosphere and wind." Journal
%of Plasma Physics 82: 635820502.
%for magnetar(cb=2) increase one order:1.6*10^（-2） T


%:::::::::::::::::::::::::::::::::::::::::::::::::::::::



B0=mean(b_phi(startPeriod:endPeriod))
%::::calculate the deflection parameter K for electrons and protons:::::
%J.D.Jackson, Classical Electrodynamics. 3rd ed. 1999: Wiley, New York.
% page 692
%deflection parameter for electrons (B0 in T, lambda in m) 
K_electron=93.4*B0*(lambda(startPeriod)*1000)    
%deflection parameter for proton K=K/1836
K_proton=K_electron/1836
%:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 



%Generates the wavetrain between startPeriod and endPeriod
%normalize the lambda to the first period
normlambda=lambda/lambda(startPeriod);
ts=1/30   ; %sampling time
for n=startPeriod:endPeriod
              
dz=normlambda(n);             %  LambdaU at nth period
k0=2*pi/dz;                   % wave vector k
t=-dz/2:ts:(dz/2-ts);    
Amplitude=b_phi(n);    %amplitude of magnetic field
tmp=Amplitude*square(k0*(t),50);
if n== startPeriod
    waveTrain=tmp;
else
waveTrain=[waveTrain,tmp];
end
end
figure(5)
plot(waveTrain)

%;;;;;;;;;;;;;; calculate the spontaneous spectrum from wavetrain;;;;;;;;;;;;;;;;;;;;
[P,f]=fft_f_p(waveTrain, 30);
P=P.*P;
figure(6)
plot(f,P)
 set(gca,'xlim',[0.6,2.5])


%negtive differential of spontaneous spectrum
%note the minus sign
dP=-gradient(P,f);

figure(1)
plot(f,dP);


%;;generate time-frequency pattern and compare with observation
yPosition=0.13; %this parameter cotrol the spectrum vertical position
f=f-yPosition;

inif1=find(f>=0.6,1,'first');
inif2=find(f>=1.4,1,'first');
f1=f(inif1:inif2);
pPlot=dP(inif1:inif2);
p1=pPlot  

%The Gain Spectrum
figure(2)
plot(f1,p1)


%Set the negative values in the gain spectrum to zero 
%and use this modified spectrum as the SASE radiation spectrum.
index=find(p1<=0);
p1(index)=0;




%
frec=omegahigh:-1*deltaOmega:omegalow;
f_num=(omegahigh-omegalow)/deltaOmega+1;
[spectrum]=spectrum_initial58(fret,t_dur,sigma,f1,p1,mu);


figure(4)
imagesc(tx*1e6,frec/1e9,spectrum)
set(gca,'YDir','normal')
xlabel('t(us)')
ylabel('Frequency (GHz)')

[spectrum1,f_t]=spectrum_shift(spectrum,dm);



figure(5)
imagesc(f_t*1e6,frec/1e9,spectrum1)
set(gca,'YDir','normal','xlim',xlim)
title('Simulated Dynamic spectrum of a GP')

xlabel('Time (Microseconds)')
ylabel('Frequency (GHz)')
h5= getframe;
[X,map] = frame2im(h5);

figure(20)
subplot(1,2,1)
plot(f1,p1)
title('Instananeous Spectrum')
xlabel('Normalized Frequency')
ylabel('Intensity (a.u.)')
text(0.63,0.75,'a)','fontsize',15,'color','black')

subplot(1,2,2)
imagesc(f_t*1e6,frec/1e9,spectrum1)
set(gca,'YDir','normal','xlim',xlim)
title('Dynamic Spectrum')
xlabel('Time (Microseconds)')
ylabel('Frequency (GHz)')
text(5.7,10.35,'b)','fontsize',15,'color','white')
figure(7)
X2=imread('Hank6.bmp');

imagesc(sum(X2,3));
colormap(gray)
h7 = getframe;
[X2,map] = frame2im(h7);



backPic=X;
[m,n,p]=size(X);

%sometime there is one pix difference in size between X and X2
%force forePic and backPic have the same size
forePic=imresize(X2,[m,n]);


blendMatrixS=sum(forePic,3)*alpha<sum(backPic,3)*(1-alpha);
blendMatrix=blendMatrixS;
blendMatrix(:,:,2)=blendMatrixS;
blendMatrix(:,:,3)=blendMatrixS;
blendPic=backPic;
blendPic(blendMatrix)=forePic(blendMatrix)*alpha+backPic(blendMatrix)*(1-alpha);
figure(9)
imshow(blendPic);
% saveas(gcf,'gb01Blend.jpg')




a='lambda1='
lambda(startPeriod)
a='lambda2='
lambda(endPeriod)
a='lambdaU='
lambdaU=mean(lambda(startPeriod:endPeriod))*1000
%lambdaU in meters
a='lambdaS='
 lambdaS=0.3/((low_freq+high_freq)/2)
 %center wavelength of observation in Fig.6 Hankins(2007)
 %0.3/frequency(GHz)=wavelength in meters
a='gamma='
gamma=sqrt(lambdaU/lambdaS/2)
%gamma=sqrt(lambdaU/lambdaObserved/2)
Proton_TeV=gamma*0.938/1000  %energy of proton in TeV

disp('Input parameters:')
 disp(['Np: ',num2str(Np),', Eta: ',num2str(FWHB),', pulsar period: ',num2str(period),]);
 disp('Output parameters:')
 disp(['Nu ',num2str(Nu),', Proton energy(TeV) : ',num2str(Proton_TeV),',lambdaU(km) : ',num2str(lambdaU/1000),',gamma : ',num2str(gamma),...
     ', K_electron : ',num2str(K_electron), ', K_proton : ',num2str(K_proton), ', r0 : ',num2str(r0)]);
    disp(['B average:',num2str(B0),sprintf('T  Radiation zone is between: %.2e', r_2pi(startPeriod)),sprintf( ' and: %.2e', r_2pi(endPeriod)),' kilometers from the central object'])
    

    figure(10)
subplot(3,1,1)
plot(x1/10^7, y1/10^7,'b');
hold on;
plot([r_2pi(startPeriod),r_2pi(endPeriod)]/10^7,[0,0] , 'y','linewidth',10);
hold off
set(gca,'xlim',[-0.1,0.6])
set(gca,'ylim',[-0.1,0.1])
ylabel('Y(10^7 km)')
title('(a)')

subplot(3,1,2)
tmp=numel(waveTrain);
%Change the unit of the lenght to 10^7 km by /10^7
wx=linspace(r_2pi(startPeriod),r_2pi(endPeriod),tmp)/10^7;
 % change the unit to nT by *10^9
plot(wx,waveTrain*10^9)
% str='B_{\phi}';
ylabel('B(nT)')
set(gca,'xlim',[0.475,0.585])
set(gca,'ylim',[-2000,2000])
title('(b)')

subplot(3,1,3)
plot(f1,(p1*1e12))
ylabel('Intensity a.u.')
xlabel('Normalized Frequency')
  set(gca,'xlim',[0.8,1.2])
  title('(c)')
