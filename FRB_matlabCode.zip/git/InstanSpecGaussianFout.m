function [P,f]=InstanSpecGaussianFout(N,eTa,SigmaWave,MuWave)
%By Q.W. Song  2019-02-14 songqw@pmo.ac.cn
 
 %;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;undulator parameter;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
 lambda0=1;                   %  Undulator's wavelength at z=0
 k0=2*3.1416/lambda0;         % Undulator's or magnetic field's spatial frequency at z=0  
 sampling_frequency=30.;         % sampling frequency of the digitalized magnetic field, 30 is sufficient
%;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
  
 W=log(1+eTa)/2*N ;               % W is not used to calculate spectrum. It is used for testing self consistency and
                                 % adjusting the trade off between eTa and N.
                                  % It is equivalent to the near field parameter W defined by Walker(1988). 
                                  % To have three peaks, W is to be around 5-6, Walker(1988) Fig.4
                                  %R. P. Walker, Nuclear Instruments and Methods in Physics Research A 267, 537-546 (1988).
                    
% % compute L(eta), the length of the undulator,  equation (1.3) of Bosco(1983) 
% the equation is perfect if N is  an integer
%    L_eta=0  ;                             
%   for i=1:N
%       L_eta=L_eta+1/(1+eTa*(i-1)/(N-1));
%       i
%   end
%   
%   L_eta=L_eta*lambda0 ;
% %end of compute L_eta     

% % compute L(eta), the length of the undulator,  equation (1.4) of Bosco(1983) 
       L_eta=N*lambda0*log(1+eTa)/eTa
    


 %wave train
 z=0:1/sampling_frequency:L_eta;
 
 si=SigmaWave* L_eta;
 mu=L_eta*MuWave;
gaussianEnvelope=normpdf(z,mu,si);
gaussianEnvelope=gaussianEnvelope./max(gaussianEnvelope);

amplitude=gaussianEnvelope;         % varied amplitude 
 phase=k0*z.*(1+eTa/(2*L_eta)*z);  %  phase is the Psi in equation(1.2) of Bosco(1983)
 wave_train=amplitude.*sin(phase);

 %fourier transform with normalized frequency f
[P,f]=fft_f_p(wave_train, sampling_frequency);



end



