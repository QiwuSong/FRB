% Clear workspace and setup initial parameters
clear all;
clc;
%parameterSet set the folder of the output mp4 file and the N number 
rootFolder='d:\output\'
solitonNumber=19
zEnd=0.6

%%%%%%%%%%%%%%


T = 100;
nt = 2^12;
dt = T / nt;
t = ((1:nt)' - (nt+1) / 2) * dt;
w = wspace(T, nt);  % Ensure 'wspace' function is defined or available in your MATLAB path
vs = fftshift(w / (2*pi));
beta2 = -1;


parfor N=solitonNumber
    outputVideoPath=strcat(rootFolder,'gb03','\')
% Check if the folder already exists
if ~exist(outputVideoPath, 'dir')
    % Folder does not exist so create it
    mkdir(outputVideoPath);
    disp(['Folder "', outputVideoPath, '" was created successfully.']);
else
    % Folder already exists
    disp(['Folder "', outputVideoPath, '" already exists.']);
end
 fig = figure('Visible', 'off');
    
    for beta3 = 0.1
        for raman = 0.07
            filename=strcat(outputVideoPath,'N',num2str(N,'%02d'),'B',num2str(beta3*100),...
                'R',num2str(raman*1000,'%02d'),'.mp4')
            videoWriter = VideoWriter(filename, 'MPEG-4');
            open(videoWriter);
            for s = 0.01  
                for z = 0.0001:0.0001:0.067
                    try
%                         runSimulation(N, beta2, beta3, raman, s, z, t, dt, vs, videoWriter, fig);
 betap = [0, 0, beta2, beta3];
    nz = 5000;
    dz = z / nz;
    u0 = solitonpulse(t);  % Ensure 'solitonpulse' function is defined
    u = sspropc(u0, dt, dz, nz, 0, betap, N^2, raman, 2 * pi * s);  % Ensure 'sspropc' function is defined
    U = fftshift(fft(u));
 [S, F, T] = spectrogram(u(1600:3000), hann(16), 14, [], 1/dt, 'centered');
    % Update figure for new simulation parameters
    clf(fig);
    parameterStr=strcat('N=',num2str(N),' beta3=',num2str(beta3),' raman=',...
   num2str(raman),' s=',num2str(s));

subplot(221);
plot(vs,unwrap(angle(u)));
 title(parameterStr);
 ylabel ('Phase');
    subplot(222);  plot(sum(abs(S),1).^2);
    title(['Pulse Evolution at z = ', num2str(z), ' units']);
   xlabel ('Time'); ylabel ('Intensity');
    subplot(223);  plot(vs, abs(U));
    xlim([-10 10]); xlabel ('Frequency'); ylabel ('Magnitude');
    subplot(224);
%     [S, F, T] = spectrogram(u(1600:3000), hann(16), 14, [], 1/dt, 'centered');
    imagesc(T, F, abs(S).^2); axis xy;
    xlabel('Time'); ylabel('Frequency');

    % Capture and write frame
    frame = getframe(fig);
    writeVideo(videoWriter, frame);
                    catch ME
                        % Log or display the error message
                        fprintf('Error in simulation N=%d, beta3=%.2f, raman=%.2f, s=%.2f, z=%.2f: %s\n', ...
                            N, beta3, raman, s, z, ME.message);
                        % Optionally, handle other cleanup or corrective actions here
                        continue; % Skip to the next iteration of the loop
                    end 
                end
                 
            end
           
            
        end
    end
    
    close(fig);
%         simulateAndSaveResults(N, beta2, t, dt, vs,outputVideoPath);
end



