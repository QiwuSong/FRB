%By Songqw
function [P,wave_train,f,dP]=spectrum_wave(eTa,Np,SigmaWave,MuWave)
if isempty(eTa)
     eTa=0.24;    % Taper parameter, spatial frequency increasing eTa over Nu periods
end
if isempty(Np)
     Np=6.5;  %the number of peaks to be appears on a spectrum
end

if isempty(MuWave)
     MuWave=0.5;  %the center of gaussian bump
end

if isempty(SigmaWave) 
     SigmaWave=0.31;  %the width of gaussian bump
end
%;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;parameter setting;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

   % Number of undulator periods
Nu=4*Np/log(1+eTa);       

 sampling_frequency=30.;         % sampling frequency of the digitalized magnetic field, 30 is sufficient
 %;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
 
 %;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;undulator parameter;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
 lambda0=1;                   %  Undulator's wavelength at z=0
 k0=2*3.1416/lambda0;         % Undulator's or magnetic field's spatial frequency at z=0  
%;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

 % compute L(eta), the length of the undulator,  equation (1.4) of Bosco(1983) 
       L_eta=Nu*lambda0*log(1+eTa)/eTa      

       %wave train
 z=0:1/sampling_frequency:L_eta;
 
 %creat a gaussian envelope for amplitude
 si=SigmaWave* L_eta;
 mu=L_eta*MuWave;
gaussianEnvelope=normpdf(z,mu,si);
gaussianEnvelope=gaussianEnvelope./max(gaussianEnvelope);
amplitude=gaussianEnvelope;        
%calculate the phase term
 phase=k0*z.*(1+eTa/(2*L_eta)*z);  %  phase is the Psi in equation(1.2) of Bosco(1983)
 
 %creat the waveform
 wave_train=amplitude.*sin(phase);
 

 %fourier transform with normalized frequency f
[P,f]=fft_f_p(wave_train, sampling_frequency);
 P=P.*P;
 dP=[0,diff(P)*(-1)];
end


