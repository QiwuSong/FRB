%the spectra with different W parameters
%the plot is the equivalence of the Fig.4 of the paper: Walker, R. P. 1988,
%Nuclear Instruments and Methods in Physics Research A, 267, 537
%By Huangyu
clear all
f=figure(5);
f.Position=[200,200,1200,600];

 MuWave=1/2;  SigmaWave=1.728; eTa=0.12;
for i=2:2:10
    w=i;
  N=2*w/log(1+eTa);  
[P,f]=InstanSpecGaussianFout(N,eTa,SigmaWave,MuWave);
P=P.*P; %Fourier square term
index=find(f>=1.6,1,'first');
P=P-P(index);
zz=1:1:length(f);
zz(:)=i;
subplot(1,2,1)
plot3(f,zz,P,'color','black')
text(1.4,i+1,0.,num2str(i/2),'fontsize',15)
 set(gca,'xlim',[0.8 1.6])
 hold on
end
% text(3.2,30,'W','fontsize',10)
hold off
view(45,20)
xlabel('$\omega/\omega_c$','Interpreter','latex','fontsize',15,'Rotation',-15,'position',[1.2,-0.2,0])
zlabel('Intensity (a.u)','fontsize',15)
ylabel('Np','fontsize',15,'Rotation',15,'position',[1.7,5,0])
 set(gca,'zlim',[0 0.35])
set(gca,'zticklabel',[],'Ztick','')
set(gca,'YTickLabel','');
set(gca,'YTick','');
text(0.85,2,0.35,'a)','fontsize',20)
box off;
    



% SASE spectrum

 MuWave=1/2;  SigmaWave=1.728; eTa=0.12;
for i=2:2:10
    w=i;
  N=2*w/log(1+eTa);  
[P,f]=InstanSpecGaussianFout(N,eTa,SigmaWave,MuWave);
P=P.*P; %Fourier square term
index=find(f>=1.6,1,'first');
P=P-P(index);
zz=1:1:length(f);
zz(:)=i;
P=[0,-diff(P)]+0.25; %Mady's theorem
subplot(1,2,2)
plot3(f,zz,P,'color','black')
text(1.4,i+1,0.25,num2str(i/2),'fontsize',15)
 set(gca,'xlim',[0.8 1.6])
 hold on
end
% text(3.2,30,'W','fontsize',10)
hold off
view(45,20)
xlabel('$\omega/\omega_c$','Interpreter','latex','fontsize',15,'Rotation',-15,'position',[1.2,-0.2,0])
zlabel('Intensity (a.u)','fontsize',15)
ylabel('Np','fontsize',15,'Rotation',15,'position',[1.7,5,0])
 set(gca,'zlim',[-0 0.5])
set(gca,'zticklabel',[],'Ztick','')
set(gca,'YTickLabel','');
set(gca,'YTick','');
text(0.85,2,0.5,'b)','fontsize',20)
box off;
    



    


