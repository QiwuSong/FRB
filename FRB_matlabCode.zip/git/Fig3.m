%by Songqw
clear global
clear 
global omegahigh omegalow
global deltaOmega dt frec f_num
omegahigh=8e9;             % The higher frequency of observation
omegalow=4.5e9;              % The lower frequency of  observation
fret=6.3e9;               % The central frequency of the spectra
t_dur=5e-3;              %The duration time of the pusle
delta_t=0.5e-3;


% DM of the inital curve is dm and disperse it by dm1
dm=9.3;
 % Number of undulator periods and Taper parameter, 
 %spatial frequency increasing eTa over N periods

eTa=0.32;  
Np=6.75
 
% Amplitude parameters of magnetic field, a gaussian envelope
 %MuWave = 1/2 according to the peak is centered. MuWave<1/2 corresponding to 
 % the lower-frequency part of the wave train has higher magnetic field 
       
 MuWave=0.60/2;  SigmaWave=0.7;     

%The backgroud of the spectrum
bg=0.0288;             % background noise level


sigma=0.03;    % spectrum width in x direction          
mu=-100;       % x location of the spectrum in the picture

%blending parameter of figure(7)
alpha=0.420; 
xx=0.7;
xlim=[xx,xx+4];

%trival parameter for discretezation
deltaOmega=1e5;         % The resolution of frequency,in unit of Hz
dt=1e-5;                % time resolution
tx=-t_dur/2:dt:t_dur/2-dt;
%;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


[P,wave_train,f,dP]=spectrum_wave(eTa,Np,SigmaWave,MuWave);


f=f-eTa/2;
inif1=find(f>=0.6,1,'first');
inif2=find(f>=1.4,1,'first');
f1=f(inif1:inif2);

 p2=P(inif1:inif2);
  pPlot=dP(inif1:inif2);
 p1=pPlot;

index=find(p1<=0);
p1(index)=0;

figure(2)
plot(f1,p1)


%
frec=omegahigh:-1*deltaOmega:omegalow;
f_num=(omegahigh-omegalow)/deltaOmega+1;
[spectrum]=spectrum_initial58(fret,t_dur,sigma,f1,p1,mu);


figure(4)
imagesc(tx*1000,frec/1e9,spectrum)
set(gca,'YDir','normal')
xlabel('t(ms)')
ylabel('Frequency (GHz)')
hold on
plot(tx,fret/1e9,'color','white')
hold off
h5= getframe;
[X,map] = frame2im(h5);
[spectrum1,f_t]=spectrum_shift(spectrum,dm);



figure(5)
imagesc(f_t*1000,frec/1e9,spectrum1)
set(gca,'YDir','normal','xlim',xlim)
% set(gca,'YDir','normal')
title(['DM=' num2str(dm)])
xlabel('t(ms)')
ylabel('Frequency (GHz)')
h5= getframe;
[X,map] = frame2im(h5);

figure(7)
X2=imread('gajjar11O.bmp');

imagesc(sum(X2,3));
colormap(gray)
% saveas(gcf,'ao02Print3d.bmp');
h7 = getframe;
[X2,map] = frame2im(h7);





backPic=X;
[m,n,p]=size(X);
%sometime there is one pix difference in size between X and X2
%force forePic and backPic have the same size
forePic=imresize(X2,[m,n]);


blendMatrixS=sum(forePic,3)*alpha<sum(backPic,3)*(1-alpha);
blendMatrix=blendMatrixS;
blendMatrix(:,:,2)=blendMatrixS;
blendMatrix(:,:,3)=blendMatrixS;
blendPic=backPic;
blendPic(blendMatrix)=forePic(blendMatrix)*alpha+backPic(blendMatrix)*(1-alpha);
figure(9)
imshow(blendPic);
% saveas(gcf,'gb01Blend.jpg')

figure(10)
subplot(2,2,1)
t_num=ceil(t_dur/dt);



plot(f1,p2)
 title('Single Particle Spectrum') 
 text(0.63,0.046,'a','fontsize',15,'color','black')
subplot(2,2,2)


plot(f1,p1)
title('Differential Spectrum')
 text(0.63,0.0125,'b','fontsize',15,'color','black')
subplot(2,2,3)
imagesc(tx*1000,frec/1e9,spectrum)
title('Dynamic Spectrum')
 text(-2.3,7.6,'c','fontsize',15,'color','white')
set(gca,'YDir','normal')
xlabel('t(ms)')
ylabel('Frequency (GHz)')
hold on
plot(tx,fret/1e9,'color','white')
hold off
subplot(2,2,4)
 imagesc(f_t*1000,frec/1e9,spectrum1)
set(gca,'YDir','normal','xlim',xlim)
% set(gca,'YDir','normal')
% title(['DM=' num2str(dm)])
 text(0.9,7.6,'d','fontsize',15,'color','white')
title('Dispersed Spectrum')
xlabel('t(ms)')
ylabel('Frequency (GHz)')
h5= getframe;
[X,map] = frame2im(h5);